from django.shortcuts import render
import requests
from bs4 import BeautifulSoup
from django.http import JsonResponse
# Create your views here.

def index(request):

    return render(request,"index.html")



def realtime(request):

    coin = "bitcoin"  #string data type


    response = requests.get("https://www.google.com/search?q=" + coin + 'price')
    content = response.content

    soup = BeautifulSoup(content, "html.parser")  #extract price html

    price = soup.find("div", attrs={
        'class': 'BNeawe iBp4i AP7Wnd'
    }).text

    return JsonResponse({"price":price}) #Price : 2323


def about(request):


    return render(request,"about.html")

def privacy(request):
    return render(request,"privacy.html")






